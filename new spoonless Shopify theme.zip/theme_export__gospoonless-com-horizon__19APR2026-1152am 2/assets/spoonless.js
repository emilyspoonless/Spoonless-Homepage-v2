/* ═══════════════════════════════════════════════════════════
   SPOONLESS — Custom Homepage JS
   ═══════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ── HERO DRIZZLE ANIMATION ──────────────────────────── */
  function animateDrizzles() {
    [
      { id: 'd2', delay: 300,  dur: 2600 },
      { id: 'd1', delay: 700,  dur: 2200 },
      { id: 'd3', delay: 1100, dur: 1800 }
    ].forEach(({ id, delay, dur }) => {
      const path = document.getElementById(id);
      if (!path) return;
      const len = path.getTotalLength();
      path.style.strokeDasharray  = len;
      path.style.strokeDashoffset = len;
      setTimeout(() => {
        path.style.transition = `stroke-dashoffset ${dur}ms cubic-bezier(0.4,0,0.2,1)`;
        path.style.strokeDashoffset = '0';
      }, delay);
    });
  }

  /* ── PRODUCT CARD MINI DRIZZLES ──────────────────────── */
  function initMiniDrizzles() {
    ['sp-drip1', 'sp-drip2'].forEach((id, i) => {
      const path = document.getElementById(id);
      if (!path) return;
      const len = path.getTotalLength();
      path.style.strokeDasharray  = len;
      path.style.strokeDashoffset = len;
      const card = path.closest('.sp-pcard');
      if (!card) return;
      const obs = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting) {
          setTimeout(() => {
            path.style.transition = 'stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)';
            path.style.strokeDashoffset = '0';
          }, 300 + i * 150);
          obs.disconnect();
        }
      }, { threshold: 0.4 });
      obs.observe(card);
    });
  }

  /* ── SCROLL REVEAL ───────────────────────────────────── */
  function initReveal() {
    document.querySelectorAll('.sp-hero [data-reveal]').forEach(el => {
      const d = parseInt(el.dataset.d || 0);
      setTimeout(() => el.classList.add('visible'), 200 + d * 160);
    });
    const rest = Array.from(document.querySelectorAll('[data-reveal]'))
      .filter(el => !el.closest('.sp-hero'));
    const obs = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    rest.forEach(el => obs.observe(el));
  }

  /* ── NAV SCROLL STATE ────────────────────────────────── */
  function initNav() {
    const nav  = document.getElementById('sp-nav');
    const hero = document.getElementById('sp-hero');
    if (!nav) return;
    const obs = new IntersectionObserver(entries => {
      nav.classList.toggle('scrolled', !entries[0].isIntersecting);
    }, { threshold: 0 });
    if (hero) obs.observe(hero);
  }

  /* ── MOBILE DRAWER ───────────────────────────────────── */
  function initDrawer() {
    const nav    = document.getElementById('sp-nav');
    const btn    = document.getElementById('sp-hamburger');
    const drawer = document.getElementById('sp-drawer');
    if (!nav || !btn || !drawer) return;

    function close() {
      nav.classList.remove('open');
      btn.setAttribute('aria-expanded', 'false');
      drawer.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('sp-menu-open');
    }

    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', String(open));
      drawer.setAttribute('aria-hidden', String(!open));
      document.body.classList.toggle('sp-menu-open', open);
    });

    drawer.querySelectorAll('a').forEach(a => a.addEventListener('click', close));
    const closeBtn = document.getElementById('sp-drawer-close');
    if (closeBtn) closeBtn.addEventListener('click', close);

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && nav.classList.contains('open')) {
        close(); btn.focus();
      }
    });
  }

  /* ── STICKY CTA ──────────────────────────────────────── */
  function initSticky() {
    const sticky   = document.getElementById('sp-sticky');
    const hero     = document.getElementById('sp-hero');
    const waitlist = document.getElementById('sp-waitlist');
    if (!sticky || !hero) return;

    const heroObs = new IntersectionObserver(entries => {
      const showing = !entries[0].isIntersecting;
      sticky.classList.toggle('show', showing);
      sticky.setAttribute('aria-hidden', String(!showing));
    }, { threshold: 0 });
    heroObs.observe(hero);

    if (waitlist) {
      const wlObs = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting) {
          sticky.classList.remove('show');
          sticky.setAttribute('aria-hidden', 'true');
        }
      }, { threshold: 0.2 });
      wlObs.observe(waitlist);
    }
  }

  /* ── MOMENTS CAROUSEL ────────────────────────────────── */
  function initMomentsCarousel() {
    const container   = document.getElementById('sp-moments-container');
    const headline    = document.getElementById('sp-moments-headline');
    const copy        = document.getElementById('sp-moments-copy');
    const imageWrap   = document.getElementById('sp-moments-image');
    const dotsWrapper = document.getElementById('sp-moments-dots');
    const prevBtn     = document.getElementById('sp-moments-prev');
    const nextBtn     = document.getElementById('sp-moments-next');
    if (!container || !dotsWrapper || !prevBtn) return;

    // Read moment data from hidden data elements rendered by Liquid
    const dataEls = document.querySelectorAll('.sp-moment-data');
    if (!dataEls.length) return;

    const moments = Array.from(dataEls).map(el => ({
      label: el.dataset.label || '',
      copy:  el.dataset.copy  || '',
      image: el.dataset.image || ''
    }));

    let current = 0;

    moments.forEach((m, i) => {
      const dot = document.createElement('button');
      dot.className = 'sp-moments__dot' + (i === 0 ? ' active' : '');
      dot.setAttribute('aria-label', 'Go to ' + m.label);
      dot.addEventListener('click', () => goTo(i));
      dotsWrapper.appendChild(dot);
    });

    function updateContent(index) {
      const m = moments[index];
      if (headline) headline.textContent = m.label;
      if (copy)     copy.textContent     = m.copy;

      if (imageWrap) {
        if (m.image) {
          imageWrap.innerHTML = '<img src="' + m.image + '" alt="' + m.label + ' moment" class="sp-moments__img">';
        } else {
          imageWrap.innerHTML = '';
        }
      }

      dotsWrapper.querySelectorAll('.sp-moments__dot').forEach((d, i) => {
        d.classList.toggle('active', i === index);
      });

      if (container) {
        container.style.animation = 'none';
        void container.offsetWidth;
        container.style.animation = 'sp-fadeInSlide 0.45s ease-out';
      }
    }

    function goTo(index) {
      current = (index + moments.length) % moments.length;
      updateContent(current);
    }

    function flashArrow(btn) {
      btn.style.background  = 'var(--sp-rust)';
      btn.style.borderColor = 'var(--sp-rust)';
      setTimeout(() => {
        btn.style.background  = '';
        btn.style.borderColor = '';
      }, 300);
    }

    prevBtn.addEventListener('click', () => { goTo(current - 1); flashArrow(prevBtn); });
    nextBtn.addEventListener('click', () => { goTo(current + 1); flashArrow(nextBtn); });

    updateContent(0);
  }

  /* ── KLAVIYO FORM SUBMISSION ─────────────────────────── */
  async function submitToKlaviyo(email, publicKey, listId) {
    try {
      const res = await fetch(
        'https://a.klaviyo.com/client/subscriptions/?company_id=' + publicKey,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'revision': '2024-10-15'
          },
          body: JSON.stringify({
            data: {
              type: 'subscription',
              attributes: {
                profile: {
                  data: { type: 'profile', attributes: { email } }
                },
                list_id: listId
              }
            }
          })
        }
      );
      return res.ok || res.status === 202;
    } catch {
      return false;
    }
  }

  /* ── HERO INLINE FORM ────────────────────────────────── */
  function initHeroForm() {
    const form  = document.getElementById('sp-hero-form');
    if (!form) return;
    const input = document.getElementById('sp-hero-email');
    const btn   = document.getElementById('sp-hero-icon');

    const klaviyoKey  = form.dataset.klaviyoKey;
    const klaviyoList = form.dataset.klaviyoList;

    function setDone() {
      if (input) {
        input.value = "You're on the list.";
        input.setAttribute('readonly', true);
        input.style.color = 'rgba(61,31,13,0.5)';
      }
      if (btn) btn.textContent = '✓';
      form.closest('.sp-hero__form-wrap') && form.closest('.sp-hero__form-wrap').querySelector('.sp-hero__form-btn') &&
        (form.closest('.sp-hero__form-wrap').querySelector('.sp-hero__form-btn').style.background = 'var(--sp-walnut)');
      localStorage.setItem('spoonless_wl', input ? input.value : 'subscribed');
    }

    if (localStorage.getItem('spoonless_wl')) setDone();

    form.addEventListener('submit', async e => {
      e.preventDefault();
      const email = input ? input.value.trim() : '';
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        if (input) {
          input.style.boxShadow = 'inset 0 0 0 2px rgba(28,20,16,0.5)';
          setTimeout(() => { input.style.boxShadow = ''; }, 1600);
        }
        return;
      }
      if (klaviyoKey && klaviyoList) {
        await submitToKlaviyo(email, klaviyoKey, klaviyoList);
      }
      setDone();
    });
  }

  /* ── WAITLIST SECTION FORM ───────────────────────────── */
  function initWaitlistForm() {
    const form   = document.getElementById('sp-wl-form');
    if (!form) return;
    const input  = document.getElementById('sp-wl-email');
    const btn    = document.getElementById('sp-wl-btn');
    const icon   = document.getElementById('sp-wl-icon');
    const status = document.getElementById('sp-wl-status');

    const klaviyoKey  = form.dataset.klaviyoKey;
    const klaviyoList = form.dataset.klaviyoList;

    function setDone() {
      if (input) {
        input.value = "You're on the list.";
        input.setAttribute('readonly', true);
        input.style.color = 'rgba(61,31,13,0.5)';
      }
      if (icon) icon.textContent = '✓';
      if (btn)  btn.style.background = '#3D1F0D';
      if (status) status.textContent = "You're on the waitlist! We'll reach out when it's time.";
      localStorage.setItem('spoonless_wl', 'subscribed');
    }

    if (localStorage.getItem('spoonless_wl')) setDone();

    form.addEventListener('submit', async e => {
      e.preventDefault();
      const email = input ? input.value.trim() : '';
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        if (input) {
          input.style.boxShadow = 'inset 0 0 0 2px rgba(28,20,16,0.5)';
          setTimeout(() => { input.style.boxShadow = ''; }, 1600);
        }
        return;
      }
      if (klaviyoKey && klaviyoList) {
        await submitToKlaviyo(email, klaviyoKey, klaviyoList);
      }
      setDone();
    });
  }

  /* ── INSTAGRAM LIGHTBOX ──────────────────────────────── */
  function initInstaLightbox() {
    const lb      = document.getElementById('sp-insta-lb');
    const lbImg   = document.getElementById('sp-insta-lb-img');
    const lbBg    = document.getElementById('sp-insta-lb-bg');
    const lbClose = document.getElementById('sp-insta-lb-close');
    if (!lb) return;

    function open(item) {
      const src = item.dataset.src;
      const img = item.querySelector('img');
      lbBg.style.background = window.getComputedStyle(item).background;
      if (img && img.complete && img.naturalWidth > 0) {
        lbImg.src = src;
        lbImg.style.display = 'block';
        lbBg.style.display  = 'none';
      } else {
        lbImg.style.display = 'none';
        lbBg.style.display  = 'block';
      }
      lb.classList.add('open');
      document.body.style.overflow = 'hidden';
    }

    function close() {
      lb.classList.remove('open');
      document.body.style.overflow = '';
      if (lbImg) lbImg.src = '';
    }

    document.querySelectorAll('.sp-insta__item').forEach(item => {
      item.addEventListener('click', () => open(item));
    });

    if (lbClose) lbClose.addEventListener('click', close);
    lb.addEventListener('click', e => { if (e.target === lb) close(); });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && lb.classList.contains('open')) close();
    });
  }

  /* ── FAQ ACCORDION ───────────────────────────────────── */
  function initFaq() {
    document.querySelectorAll('.sp-faq__item').forEach(item => {
      const question = item.querySelector('.sp-faq__question');
      if (!question) return;
      question.addEventListener('click', () => {
        const isOpen = item.classList.contains('open');
        document.querySelectorAll('.sp-faq__item.open').forEach(el => el.classList.remove('open'));
        if (!isOpen) item.classList.add('open');
      });
    });
  }

  /* ── INIT ────────────────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', () => {
    animateDrizzles();
    initReveal();
    initNav();
    initDrawer();
    initSticky();
    initMomentsCarousel();
    initInstaLightbox();
    initHeroForm();
    initWaitlistForm();
    initMiniDrizzles();
    initFaq();
  });

})();
