(function() {
  'use strict';

  // ── HERO DRIZZLE ANIMATION ─────────────────────────
  function animateDrizzles() {
    [
      { id: 'd2', delay: 300,  dur: 2600 },
      { id: 'd1', delay: 700,  dur: 2200 },
      { id: 'd3', delay: 1100, dur: 1800 }
    ].forEach(({ id, delay, dur }) => {
      const path = document.getElementById(id);
      if (!path) return;
      const len = path.getTotalLength();
      path.style.strokeDasharray  = len;
      path.style.strokeDashoffset = len;
      setTimeout(() => {
        path.style.transition = `stroke-dashoffset ${dur}ms cubic-bezier(0.4,0,0.2,1)`;
        path.style.strokeDashoffset = '0';
      }, delay);
    });
  }

  // ── PRODUCT CARD MINI DRIZZLES ─────────────────────
  function initMiniDrizzles() {
    ['drip1','drip2'].forEach((id, i) => {
      const path = document.getElementById(id);
      if (!path) return;
      const len = path.getTotalLength();
      path.style.strokeDasharray  = len;
      path.style.strokeDashoffset = len;
      const card = path.closest('.pcard');
      if (!card) return;
      const obs = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting) {
          setTimeout(() => {
            path.style.transition = 'stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)';
            path.style.strokeDashoffset = '0';
          }, 300 + i * 150);
          obs.disconnect();
        }
      }, { threshold: 0.4 });
      obs.observe(card);
    });
  }

  // ── SCROLL REVEAL ──────────────────────────────────
  function initReveal() {
    // Hero items: trigger immediately (above fold)
    document.querySelectorAll('.hero [data-reveal]').forEach(el => {
      const d = parseInt(el.dataset.d || 0);
      setTimeout(() => el.classList.add('visible'), 200 + d * 160);
    });
    // Everything else: IntersectionObserver
    const rest = Array.from(document.querySelectorAll('[data-reveal]'))
      .filter(el => !el.closest('.hero'));
    const obs = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    rest.forEach(el => obs.observe(el));
  }

  // ── NAV SCROLL STATE ───────────────────────────────
  function initNav() {
    const nav  = document.getElementById('nav');
    const hero = document.getElementById('hero');
    const obs = new IntersectionObserver(entries => {
      nav.classList.toggle('scrolled', !entries[0].isIntersecting);
    }, { threshold: 0 });
    if (hero) obs.observe(hero);
  }

  // ── MOBILE NAV DRAWER ─────────────────────────────
  function initDrawer() {
    const nav    = document.getElementById('nav');
    const btn    = document.getElementById('hamburger');
    const drawer = document.getElementById('drawer');

    function close() {
      nav.classList.remove('open');
      btn.setAttribute('aria-expanded', 'false');
      drawer.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('menu-open');
    }

    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open);
      drawer.setAttribute('aria-hidden', !open);
      document.body.classList.toggle('menu-open', open);
    });

    drawer.querySelectorAll('a').forEach(a => a.addEventListener('click', close));
    document.getElementById('drawer-close').addEventListener('click', close);

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && nav.classList.contains('open')) {
        close(); btn.focus();
      }
    });
  }

  // ── STICKY CTA ─────────────────────────────────────
  function initSticky() {
    const sticky   = document.getElementById('sticky');
    const hero     = document.getElementById('hero');
    const waitlist = document.getElementById('waitlist');
    if (!sticky || !hero) return;

    const heroObs = new IntersectionObserver(entries => {
      const showing = !entries[0].isIntersecting;
      sticky.classList.toggle('show', showing);
      sticky.setAttribute('aria-hidden', !showing);
    }, { threshold: 0 });
    heroObs.observe(hero);

    if (waitlist) {
      const wlObs = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting) {
          sticky.classList.remove('show');
          sticky.setAttribute('aria-hidden', 'true');
        }
      }, { threshold: 0.2 });
      wlObs.observe(waitlist);
    }
  }

  // ── MOMENTS CAROUSEL ──────────────────────────────────
  function initMomentsCarousel() {
    const moments = [
      {
        label: 'Breakfast',
        copy: 'Drizzle over yogurt, granola, and berries for a protein-packed start. No jar. No spoon. Just the good part.',
        image: 'yogurt-bowl.png'
      },
      {
        label: 'Post Workout',
        copy: 'High protein, clean label. Drizzle over a rice cake or stir into a recovery shake — refuel without the compromise.'
      },
      {
        label: 'Lunch',
        copy: 'Apple slices, celery sticks, a grain bowl. Spoonless makes the midday meal worth looking forward to.'
      },
      {
        label: 'Afternoon Snack',
        copy: 'That 3pm slump doesn\'t stand a chance. Crackers, pretzels, or straight from the bottle — no guilt required.'
      },
      {
        label: 'Dinner',
        copy: 'A finishing drizzle over roasted veg, grilled chicken, or noodles. The condiment shelf finally has a worthy anchor.'
      },
      {
        label: 'Dessert',
        copy: 'Ice cream, brownies, banana slices — Hazelnut Cacao was made for this moment. The upgrade you didn\'t know you needed.'
      }
    ];

    let currentIndex = 0;

    const container = document.getElementById('moments-container');
    const headline  = document.getElementById('moments-headline');
    const copy      = document.getElementById('moments-copy');
    const image     = document.getElementById('moments-image');
    const dotsWrapper = document.getElementById('moments-dots-wrapper');
    const prevBtn   = document.getElementById('moments-prev');
    const nextBtn   = document.getElementById('moments-next');

    // Build dots
    moments.forEach((m, i) => {
      const dot = document.createElement('button');
      dot.className = 'moments__dot' + (i === 0 ? ' active' : '');
      dot.setAttribute('aria-label', 'Go to ' + m.label);
      dot.addEventListener('click', () => goTo(i));
      dotsWrapper.appendChild(dot);
    });

    function updateContent(index) {
      const m = moments[index];
      headline.textContent = m.label;
      copy.textContent = m.copy;

      if (m.image) {
        image.innerHTML = '<img src="' + m.image + '" alt="' + m.label + ' moment" class="moments__img">';
      } else {
        image.innerHTML = '';
      }

      dotsWrapper.querySelectorAll('.moments__dot').forEach((d, i) => {
        d.classList.toggle('active', i === index);
      });

      container.style.animation = 'none';
      void container.offsetWidth;
      container.style.animation = 'fadeInSlide 0.45s ease-out';
    }

    function goTo(index) {
      currentIndex = (index + moments.length) % moments.length;
      updateContent(currentIndex);
    }

    function flashArrow(btn) {
      btn.style.background    = 'var(--rust)';
      btn.style.borderColor   = 'var(--rust)';
      setTimeout(() => {
        btn.style.background  = '';
        btn.style.borderColor = '';
      }, 300);
    }

    prevBtn.addEventListener('click', () => { goTo(currentIndex - 1); flashArrow(prevBtn); });
    nextBtn.addEventListener('click', () => { goTo(currentIndex + 1); flashArrow(nextBtn); });

    updateContent(0);
  }

  // ── WAITLIST FORM ──────────────────────────────────
  function initForm() {
    const form   = document.getElementById('wl-form');
    const input  = document.getElementById('wl-email');
    const btn    = document.getElementById('wl-btn');
    const icon   = document.getElementById('wl-icon');
    const status = document.getElementById('wl-status');

    function setDone() {
      form.classList.add('done');
      input.value = "You're on the list.";
      input.setAttribute('readonly', true);
      input.style.color = 'rgba(61,31,13,0.5)';
      icon.textContent = '✓';
      btn.style.background = '#3D1F0D';
      status.textContent = "You're on the waitlist! We'll reach out when it's time.";
    }

    // Persist state
    if (localStorage.getItem('spoonless_wl')) setDone();

    form.addEventListener('submit', e => {
      e.preventDefault();
      const email = input.value.trim();
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        input.style.boxShadow = 'inset 0 0 0 2px rgba(28,20,16,0.5)';
        setTimeout(() => { input.style.boxShadow = ''; }, 1600);
        return;
      }
      // Production: POST to Klaviyo / Mailchimp here
      localStorage.setItem('spoonless_wl', email);
      setDone();
    });
  }

  // ── INIT ───────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => {
    animateDrizzles();
    initReveal();
    initNav();
    initDrawer();
    initSticky();
    initMomentsCarousel();
    initInstaLightbox();
    initForm();
    initMiniDrizzles();
  });

  function initInstaLightbox() {
    const lb      = document.getElementById('insta-lb');
    const lbImg   = document.getElementById('insta-lb-img');
    const lbBg    = document.getElementById('insta-lb-bg');
    const lbClose = document.getElementById('insta-lb-close');

    function open(item) {
      const src = item.dataset.src;
      const img = item.querySelector('img');
      lbBg.style.background = window.getComputedStyle(item).background;
      if (img && img.complete && img.naturalWidth > 0) {
        lbImg.src = src;
        lbImg.style.display = 'block';
        lbBg.style.display  = 'none';
      } else {
        lbImg.style.display = 'none';
        lbBg.style.display  = 'block';
      }
      lb.classList.add('open');
      document.body.style.overflow = 'hidden';
    }

    function close() {
      lb.classList.remove('open');
      document.body.style.overflow = '';
      lbImg.src = '';
    }

    document.querySelectorAll('.insta__item').forEach(item => {
      item.addEventListener('click', () => open(item));
    });

    lbClose.addEventListener('click', close);
    lb.addEventListener('click', e => { if (e.target === lb) close(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && lb.classList.contains('open')) close(); });
  }

})();